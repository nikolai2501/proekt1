﻿namespace fuck_pepe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rng_but = new System.Windows.Forms.Button();
            this.let_but = new System.Windows.Forms.Button();
            this.op_but = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rng_but
            // 
            this.rng_but.Location = new System.Drawing.Point(12, 247);
            this.rng_but.Name = "rng_but";
            this.rng_but.Size = new System.Drawing.Size(254, 191);
            this.rng_but.TabIndex = 1;
            this.rng_but.Text = "Make a random number";
            this.rng_but.UseVisualStyleBackColor = true;
            this.rng_but.Click += new System.EventHandler(this.rng_but_Click);
            // 
            // let_but
            // 
            this.let_but.Location = new System.Drawing.Point(272, 247);
            this.let_but.Name = "let_but";
            this.let_but.Size = new System.Drawing.Size(246, 191);
            this.let_but.TabIndex = 2;
            this.let_but.Text = "Make a random letter";
            this.let_but.UseVisualStyleBackColor = true;
            this.let_but.Click += new System.EventHandler(this.let_but_Click);
            // 
            // op_but
            // 
            this.op_but.Location = new System.Drawing.Point(524, 247);
            this.op_but.Name = "op_but";
            this.op_but.Size = new System.Drawing.Size(264, 191);
            this.op_but.TabIndex = 3;
            this.op_but.Text = "Make a random operator";
            this.op_but.UseVisualStyleBackColor = true;
            this.op_but.Click += new System.EventHandler(this.op_but_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(416, 278);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(144, 88);
            this.label2.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(461, 51);
            this.label2.TabIndex = 5;
            this.label2.Text = "Shows your result here";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.op_but);
            this.Controls.Add(this.let_but);
            this.Controls.Add(this.rng_but);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rng_but;
        private System.Windows.Forms.Button let_but;
        private System.Windows.Forms.Button op_but;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

