﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace fuck_pepe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rng_but_Click(object sender, EventArgs e)
        {
            Random rng = new Random();
            int dice = rng.Next(-2147483647, 2147483647);
            string diceString = dice.ToString();
            label2.Text = diceString;
        }

        private void let_but_Click(object sender, EventArgs e)
        {
            Random rng = new Random();
        
            char result = (char)('A' + (Math.Abs(rng.Next()) % 26));
            label2.Text = result+" ";
        }

        private void op_but_Click(object sender, EventArgs e)
        {
            string[] operators = { "Sledge", "Thatcher", "Ash", "Thermite", "Twitch", "Montagne", "Glaz", "Fuze", "Blitz", "IQ",
                               "Buck", "Blackbeard", "Capitao", "Hibana", "Jackal", "Ying", "Zofia", "Dokkaebi", "Lion", "Finka",
                               "Maverick", "Nomad", "Gridlock", "Nokk", "Amaru", "Kali", "Iana", "Ace", "Zero", "Flores",
                               "Osa", "Sens", "Grim", "Brava", "Ram", "Deimos"};
            Random rng = new Random();
            string randomOperator = operators[rng.Next(operators.Length)];
            label2.Text = randomOperator;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
