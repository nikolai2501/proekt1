﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int c= int.Parse(Console.ReadLine());
            Random rnd = new Random();
            Console.WriteLine("random numbers part 1");
            for (int i =0; i < c; i++)
            {     
                int dice = rnd.Next(-2147483647, 2147483647);
                Console.WriteLine(dice);
            }
            Console.WriteLine("random number part 2");
            for (int i = 0; i < c; i++)
            {
                int dice = rnd.Next(-2147483647, 2147483647);
                Console.WriteLine(dice);
            }
            Console.ReadKey();
        }
    }
}
